The module line names the module and exposes main, which Elm looks for when starting your app.
We import Browser to run in the browser, and Html to build the page.
main uses Browser.sandbox, which is the simplest way to run an Elm app. It needs three things:
