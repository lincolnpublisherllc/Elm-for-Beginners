That is a complete Elm program. Next we add state and a bit of interaction so you can see the core architecture.
