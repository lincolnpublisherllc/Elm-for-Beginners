> List.map (\n -> n * 2) [1,2,3]
