Replace the contents of src/Main.elm with this:
module Main exposing (main)
