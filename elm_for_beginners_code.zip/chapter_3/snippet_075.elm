Keep the code within Browser.sandbox so you focus on model, update, and view.
