case msg of
Increment ->
{ model | count = model.count + 1, error = Nothing }
