mkdir hello-world
cd hello-world
elm init
