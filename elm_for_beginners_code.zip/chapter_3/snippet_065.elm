, button [ onClick ApplyDraft ] [ text "Set" ]
