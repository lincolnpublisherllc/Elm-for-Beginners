ModelA data structure that represents the current state of your app.
