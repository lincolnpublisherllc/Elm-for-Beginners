> String.repeat 3 "hi"
