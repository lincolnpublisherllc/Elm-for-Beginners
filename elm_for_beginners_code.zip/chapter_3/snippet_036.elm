Elm gives you three core tools. You will use all of them while learning.
elm repl
