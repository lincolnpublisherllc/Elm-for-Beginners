[ button [ onClick Decrement ] [ text "-" ]
, button [ onClick Increment ] [ text "+" ]
, button [ onClick Reset ] [ text "Reset" ]
