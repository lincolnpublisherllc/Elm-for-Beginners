ApplyDraft ->
case String.toInt model.draft of
Just n ->
{ model | count = n, draft = "", error = Nothing }
