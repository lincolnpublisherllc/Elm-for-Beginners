viewError : Maybe String -> Html msg
