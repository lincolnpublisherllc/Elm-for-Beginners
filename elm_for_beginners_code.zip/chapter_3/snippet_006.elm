Browser.sandbox
{ init = ()
, update = \_ model -> model
, view = \_ -> text "Hello, Elm!"
}
