elm make src/Main.elm --output=main.js
If the code has a type mismatch or a missing import, the compiler prints a message in plain language. Read it carefully. It explains the expected type, what it found, and where to look.
