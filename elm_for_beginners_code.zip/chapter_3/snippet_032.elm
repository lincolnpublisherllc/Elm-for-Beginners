MsgMsg is a custom type that lists possible events. Here we have three. Each one is a label with no data attached, which means they are simple signals.
updateupdate uses a case expression to handle each message. It returns a new model each time. Notice there is no mutation. We copy the record and change a field, which is how updates work in Elm.
viewview receives the model and returns HTML. We display the count and render three buttons. Each button has an onClick event that creates one of our messages.
