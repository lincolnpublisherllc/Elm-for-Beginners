The update function parses with String.toInt. The result is a Maybe Int. We handle both Just n and Nothing, which avoids hidden null problems.
