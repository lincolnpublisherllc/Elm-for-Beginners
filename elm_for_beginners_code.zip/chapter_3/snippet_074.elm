Forgetting an importIf you use String.fromInt but forget import String, Elm will tell you it cannot find the value. Add the import and compile again.
Wrong type in updateIf a branch in update returns the wrong type, the compiler points to the exact branch. Make sure every branch returns Model.
Not handling all messagesIf you add a new constructor to Msg but forget to update the case expression, Elm warns you that the pattern match is not exhaustive. Add the missing branch.
Confusing record update syntaxUse { model | field = newValue } to change one field in a record. Do not try to mutate in place.
String concatenation versus number additionUse String.fromInt when joining a number with a string.
