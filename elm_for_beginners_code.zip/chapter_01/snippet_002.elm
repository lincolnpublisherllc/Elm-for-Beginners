All product names, logos, trademarks, and registered trademarks are the property of their respective owners. Mention of any brand does not imply endorsement.
