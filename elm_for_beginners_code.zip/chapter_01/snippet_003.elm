As a buyer of Elm for Beginners, you get exclusive access to a full repository of Unity project scripts and resources. These are packaged in a ZIP file so you can easily download and use them.
