case msg of
Increment ->
{ model | count = model.count + 1 }
