type is usually "application" for front-end apps.
