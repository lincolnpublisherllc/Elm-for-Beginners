npm install -g elm
elm --version
