elm make src/Main.elm --output=main.js
