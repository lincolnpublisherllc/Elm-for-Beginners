sudo apt update
sudo apt install -y nodejs npm
