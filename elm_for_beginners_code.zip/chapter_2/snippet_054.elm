elm repl starts and evaluates 2 + 2
elm init creates elm.json and src
elm reactor serves your project and opens in a browser
elm make src/Main.elm --output=main.js compiles without errors
