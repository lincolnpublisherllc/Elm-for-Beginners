Run elm --version
Start elm repl, evaluate String.reverse "Elm"
