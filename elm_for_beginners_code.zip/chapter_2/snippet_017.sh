elm repl for interactive experiments
elm make to compile programs
elm reactor to serve and compile programs during development
