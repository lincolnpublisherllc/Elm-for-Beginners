elm reactor serves your project and compiles on demand, which is perfect while learning.
