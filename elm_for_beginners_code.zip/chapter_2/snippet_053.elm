elm --version prints a version
