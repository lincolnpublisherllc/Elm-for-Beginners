> import String
> String.toUpper "elm"
