The view uses Html.input and onInput to capture text
Use String.trim to display a clean greeting
