[ div [] [ text ("Count: " ++ String.fromInt model.count) ]
