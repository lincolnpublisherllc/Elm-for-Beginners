> List.map (\n -> n * n) [1,2,3,4]
