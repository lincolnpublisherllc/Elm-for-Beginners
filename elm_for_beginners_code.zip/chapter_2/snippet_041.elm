Browser.sandbox to wire everything together
