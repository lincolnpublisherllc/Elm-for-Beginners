mkdir hello-elm
cd hello-elm
elm init
