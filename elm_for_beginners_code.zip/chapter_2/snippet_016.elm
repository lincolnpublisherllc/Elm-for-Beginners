Quick testCreate a file Test.elm, type something simple, and confirm the editor highlights syntax, offers type info on hover, and formats on save.
