When you run elm init, Elm creates elm.json. This file tells Elm the type of project, your source directories, and your dependencies. For a beginner app, it will look something like:
{
