Each branch returns a String. The whole if expression also returns a String.
