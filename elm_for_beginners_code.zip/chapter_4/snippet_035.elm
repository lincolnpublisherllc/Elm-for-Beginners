case items of
x :: _ ->
