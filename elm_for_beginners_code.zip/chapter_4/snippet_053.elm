case ( String.toInt "3", String.toInt "4" ) of
( Just a, Just b ) ->
