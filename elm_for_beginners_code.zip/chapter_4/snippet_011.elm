Text values. Strings are immutable sequences of characters.
