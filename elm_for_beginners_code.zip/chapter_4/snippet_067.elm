Use case on four String.toInt results or combine them step by step.
