When you parse numbers from strings, or look up dictionary entries, you will get Maybe. Handle both cases with case or helper functions such as Maybe.withDefault.
parseOrZero : String -> Int
