A record type Budget with fields income : Int, rent : Int, food : Int, other : Int.
A function remaining : Budget -> Int that computes income - rent - food - other.
A function fromStrings : String -> String -> String -> String -> Result String Budget that parses a budget from four strings. Use String.toInt and validate that all values are nonnegative. Return Err with a helpful message if any field fails.
A function label : Budget -> String that returns a status string:
