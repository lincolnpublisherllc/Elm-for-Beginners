String.toUpper s ++ "!"
