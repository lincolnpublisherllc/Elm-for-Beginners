Exercise 1. Annotate everythingTake a small file and add explicit type annotations to all top level values and functions. Compile and confirm no errors. Notice how the code reads like documentation.
