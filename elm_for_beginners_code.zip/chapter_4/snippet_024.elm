Type annotations and type inference
