"$" ++ String.fromInt cents
