Create a small module Budget.elm that models a monthly budget with primitive types and a record.
