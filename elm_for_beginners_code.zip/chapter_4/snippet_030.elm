String.toInt s
String.toInt returns Maybe Int to represent success or failure. There is no hidden null. You must handle both outcomes.
