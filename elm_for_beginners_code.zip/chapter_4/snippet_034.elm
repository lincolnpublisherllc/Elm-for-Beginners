Maybe at the edge of primitives
You will encounter Maybe whenever a result might be missing. It is a type safe way to represent absence.
safeHead : List a -> Maybe a
