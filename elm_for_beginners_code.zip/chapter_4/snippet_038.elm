Maybe.withDefault 0 (String.toInt s)
