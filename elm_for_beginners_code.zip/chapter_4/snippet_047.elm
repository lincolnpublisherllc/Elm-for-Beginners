String.fromFloat (round (x * 100) |> toFloat |> (\cents -> cents / 100))
