String.fromFloat (ratio * 100) ++ "%"
