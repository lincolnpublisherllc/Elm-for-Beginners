String.toLower a == String.toLower b
