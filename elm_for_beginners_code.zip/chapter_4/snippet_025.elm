addOne : number -> number
The number type variable covers both Int and Float where the operations allow it. If you later use addOne with a Float only operation, the compiler will narrow the type and tell you.
