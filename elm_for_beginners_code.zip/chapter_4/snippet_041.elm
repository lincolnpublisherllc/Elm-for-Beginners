A short tour of handy functions you will use often:
cap : String -> String
