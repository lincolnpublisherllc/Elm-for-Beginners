case compare n 0 of
LT ->
