4) Missing imports for helpersIf you use String.fromInt or String.toInt, import String. The compiler will tell you when a value is unknown.
