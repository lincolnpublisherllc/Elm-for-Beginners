Elm is an expression based language. Every if, case, and function body produces a value. There are no bare statements. This encourages small, focused functions and clear data flow.
status : Int -> String
