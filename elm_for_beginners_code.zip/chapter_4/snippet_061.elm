type alias Score =
{ value : Int
