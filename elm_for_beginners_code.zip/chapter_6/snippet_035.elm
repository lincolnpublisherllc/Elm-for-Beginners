first :: rest ->
"First: " ++ String.fromInt first
++ ", length: " ++ String.fromInt (List.length xs)
We used xs outside the case so it is still available after destructuring.
