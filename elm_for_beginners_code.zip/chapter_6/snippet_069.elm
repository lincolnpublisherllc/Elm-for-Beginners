3) Non-exhaustive case
