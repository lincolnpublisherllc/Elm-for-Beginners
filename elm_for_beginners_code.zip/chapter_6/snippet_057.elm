case maybeAge of
Just n ->
"Age " ++ String.fromInt n
