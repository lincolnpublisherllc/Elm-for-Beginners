Guard-like checks with case
Elm does not have Haskell-style guards, but you can combine case and if clearly.
describeTemp : Maybe Float -> String
