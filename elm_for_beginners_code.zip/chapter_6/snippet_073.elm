-- better
lengthOf : List a -> Int
