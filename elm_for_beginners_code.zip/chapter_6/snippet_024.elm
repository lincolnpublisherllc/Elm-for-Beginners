You want the compiler to keep you honest when the type later changes.
