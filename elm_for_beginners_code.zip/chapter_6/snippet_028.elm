type alias Person =
{ name : String, age : Int }
