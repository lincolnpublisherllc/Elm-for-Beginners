Build a small module Tickets.elm that prices event tickets.
