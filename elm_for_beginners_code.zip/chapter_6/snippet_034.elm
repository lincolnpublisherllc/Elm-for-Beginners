case xs of
[] ->
