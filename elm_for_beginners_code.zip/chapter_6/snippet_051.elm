Use case when choices come from a finite set.
type Page
