type Tier = Regular | Student | Senior
