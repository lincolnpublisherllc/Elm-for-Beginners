List.filter (\s -> String.length s > 0) names
