type Status = Loading | Loaded | Failed String
