When branches reflect different shapes or named cases, switch to case.
