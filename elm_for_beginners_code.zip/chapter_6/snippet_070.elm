-- wrong
case maybeName of
Just name -> name
