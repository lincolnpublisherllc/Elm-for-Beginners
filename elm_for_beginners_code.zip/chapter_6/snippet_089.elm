price : Tier -> IntRegular is 5000, Student is 3000, Senior is 3500.
discounted : Tier -> Int -> IntGiven a tier and quantity, return the total in naira. If quantity is 10 or more, apply a 10 percent discount. Use if for the threshold and case for the tier.
summary : Tier -> Int -> StringReturn a message like "10 Student tickets: ₦27000" after discount.
