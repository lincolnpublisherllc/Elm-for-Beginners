Use if for simple true or false decisions. When you are choosing among several shapes or possibilities, move to case.
