List helpers such as List.map, List.filter, and List.foldl which encapsulate the control flow for common patterns.
