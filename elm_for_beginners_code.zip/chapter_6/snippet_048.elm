Base case for the empty list.
Recursive case that processes the head and recurses on the tail.
Benefits of loop-free control flow
