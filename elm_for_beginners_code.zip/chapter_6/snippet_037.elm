Prefer case when matching on shapes, custom types, or when you need more than two branches.
When you find yourself chaining many if else if branches, consider a case to make intent clearer.
