headOr : a -> List a -> a
Return the first element or the default if the list is empty. Use case.
