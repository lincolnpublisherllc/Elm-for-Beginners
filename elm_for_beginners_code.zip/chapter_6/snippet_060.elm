type alias Line =
{ price : Float, qty : Int }
