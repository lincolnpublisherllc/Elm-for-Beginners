case c of
'a' -> True
'e' -> True
'i' -> True
'o' -> True
'u' -> True
_   -> False
