case selects behavior by matching the shape of a value. It is the idiomatic way to branch on custom types like Msg, Maybe, or Result, and on collections such as lists and tuples.
