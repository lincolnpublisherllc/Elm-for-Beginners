List.foldl (\n acc -> acc + n) 0 xs
