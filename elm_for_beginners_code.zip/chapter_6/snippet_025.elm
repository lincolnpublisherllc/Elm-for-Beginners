Pattern matching is how case binds names and checks shapes at the same time. Here is a small tour.
