Convert with String.fromInt when building the label.
