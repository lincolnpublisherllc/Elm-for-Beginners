4) Processing a list of records
