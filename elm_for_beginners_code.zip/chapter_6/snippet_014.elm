type alias User =
{ id : Int, name : String }
