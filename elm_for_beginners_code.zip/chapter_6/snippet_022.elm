Use case for exhaustive intent
Reach for case when:
