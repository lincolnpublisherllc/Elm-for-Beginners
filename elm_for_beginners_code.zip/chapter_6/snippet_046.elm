case list of
[] ->
