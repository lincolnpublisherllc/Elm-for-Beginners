Choosing between if and case
