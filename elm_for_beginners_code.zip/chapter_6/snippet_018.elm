Match the empty list or a head and tail. This is the building block of many list algorithms.
headLabel : List a -> String
