You need to cover all possibilities of a Maybe or Result.
