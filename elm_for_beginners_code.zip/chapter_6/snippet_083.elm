shape : List a -> String
Return "empty", "singleton", or "many" using a case on the list.
