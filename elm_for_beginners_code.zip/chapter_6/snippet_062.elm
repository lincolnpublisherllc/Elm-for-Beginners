|> List.map (\l -> l.price * toFloat l.qty)
|> List.sum
