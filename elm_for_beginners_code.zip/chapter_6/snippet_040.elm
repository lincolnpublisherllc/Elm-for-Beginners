List.map (\n -> n * 2) nums
