Easier reasoning. The shape of the data guides the control flow.
