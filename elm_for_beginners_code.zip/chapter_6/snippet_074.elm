List.foldl (\_ acc -> acc + 1) 0 xs
