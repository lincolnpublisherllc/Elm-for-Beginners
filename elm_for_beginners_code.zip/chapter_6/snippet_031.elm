case list of
a :: b :: _ ->
