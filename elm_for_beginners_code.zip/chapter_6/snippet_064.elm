|> List.filter (\l -> l.price * toFloat l.qty >= minSubtotal)
