The compiler checks that you covered every constructor. If you add a new constructor later, the compiler will remind you to update each case. This is one of Elm’s best features for safe refactoring.
