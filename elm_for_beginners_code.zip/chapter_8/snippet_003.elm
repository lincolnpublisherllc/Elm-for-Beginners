[ 1, "two" ]  -- compile error
