Fold reduces a list to a single value. Use List.foldl for most tasks.
sum : List Int -> Int
