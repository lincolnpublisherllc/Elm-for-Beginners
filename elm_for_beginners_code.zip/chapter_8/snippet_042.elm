Combine both to represent collections of entities.
type alias Product =
{ id : Int
