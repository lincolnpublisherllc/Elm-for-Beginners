Tuples bundle a small fixed number of values. They are great for simple pairs and triples where names would be noise.
