List.filter .inStock items
