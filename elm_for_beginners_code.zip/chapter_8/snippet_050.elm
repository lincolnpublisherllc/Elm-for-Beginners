List.sortBy .price
