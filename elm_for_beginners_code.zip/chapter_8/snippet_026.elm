"(" ++ String.fromFloat x ++ ", " ++ String.fromFloat y ++ ")"
