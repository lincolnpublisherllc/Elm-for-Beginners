Records are named collections of fields. They are Elm’s workhorse for modeling real entities.
