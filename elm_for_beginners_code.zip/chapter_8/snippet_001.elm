Lists are ordered, immutable sequences of values that all share the same type.
