List.filter (\s -> String.length s <= 4) xs
