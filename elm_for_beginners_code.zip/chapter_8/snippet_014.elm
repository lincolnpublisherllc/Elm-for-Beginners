List.foldl max fallback xs
