List.filter (\n -> modBy 2 n == 0) xs
|> List.head
