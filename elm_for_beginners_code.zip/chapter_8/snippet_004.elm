-- length
List.length [ 10, 20, 30 ] -- 3
