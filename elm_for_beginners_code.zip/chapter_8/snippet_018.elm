List.member "Ada" xs
