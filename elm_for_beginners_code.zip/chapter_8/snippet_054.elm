List.foldl
(\p ( yes, no ) ->
