Elm enforces a single element type per list. This fails:
