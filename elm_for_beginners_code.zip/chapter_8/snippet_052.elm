|> List.sortBy .name
|> List.sortBy .price
