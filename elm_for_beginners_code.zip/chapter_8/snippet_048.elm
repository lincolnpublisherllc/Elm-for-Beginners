|> List.map (\p -> p.price)
|> List.sum
Note the field accessor shorthand .inStock which means \p -> p.inStock.
