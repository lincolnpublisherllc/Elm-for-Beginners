type alias Profile =
{ user : User
