type alias Address =
{ street : String, city : String, country : String }
