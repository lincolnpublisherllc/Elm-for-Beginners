case returns a value.
