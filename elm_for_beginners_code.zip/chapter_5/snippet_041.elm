"Items: " ++ String.fromInt 12
