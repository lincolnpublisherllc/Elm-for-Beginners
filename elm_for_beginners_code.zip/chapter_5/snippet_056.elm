"Subtotal: $" ++ String.fromFloat total
++ " | Tax: " ++ String.fromFloat (total * taxRate)
++ " | Total: $" ++ String.fromFloat grand
