String.toInt s
|> Maybe.withDefault 0
