5) Remainder signmodBy d n returns a result with the sign of the divisor in Elm. For nonnegative values this is not a concern. For negative values, document intent or normalize first.
