type alias LineItem =
{ title : String
