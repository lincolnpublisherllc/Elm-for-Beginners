|> (\c -> case c of
LT -> -1
EQ -> 0
GT -> 1
