3) String plus numberUse String.fromInt or String.fromFloat.
