Each branch returns a String. The whole if returns a String.
