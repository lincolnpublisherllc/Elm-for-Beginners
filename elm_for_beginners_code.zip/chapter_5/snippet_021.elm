Elm’s Basics module provides helpers that often read better than raw operators.
clampScore : Int -> Int
