For formatMoney, multiply by 100, round, then divide by 100 to keep two decimals, then use String.fromFloat.
