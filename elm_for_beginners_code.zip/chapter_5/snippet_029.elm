"$" ++ String.fromFloat x
