"Score: " ++ String.fromInt n
