Create a small module Calc.elm that provides a few user-facing helpers:
sum3 : Float -> Float -> Float -> Float
mean : List Float -> Maybe Float
formatMoney : Float -> String that prints with two decimal places
safePercent : Float -> Float -> String returns a percent string for part over whole, and returns "n/a" if whole is zero
