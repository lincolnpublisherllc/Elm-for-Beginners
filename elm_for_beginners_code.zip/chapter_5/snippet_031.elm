String.fromFloat (r * 100) ++ "%"
