case for shape-based choices
