3 + 2.5   -- compile error
