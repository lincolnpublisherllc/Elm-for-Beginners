List.map lineTotal items
|> List.sum
