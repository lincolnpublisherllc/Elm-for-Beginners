case String.toFloat s of
Just x ->
