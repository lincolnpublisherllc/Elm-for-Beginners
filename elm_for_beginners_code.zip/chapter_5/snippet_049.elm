"Total: $" ++ String.fromFloat total
