A Taste of Elm’s Syntax and Rhythm
