if String.length value >= minLen then
