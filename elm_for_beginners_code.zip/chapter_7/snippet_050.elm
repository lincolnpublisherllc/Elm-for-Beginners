errors ++ [ field ++ " must be at least " ++ String.fromInt minLen ++ " characters" ]
This shows small functions with clear parameters and a pipeline of validation steps.
