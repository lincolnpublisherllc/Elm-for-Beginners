mapRec : (a -> b) -> List a -> List b
Use recursion with a base case and a recursive case.
