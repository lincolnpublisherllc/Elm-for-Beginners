Consider Maybe for the mean of an empty list, then turn it into a friendly label.
