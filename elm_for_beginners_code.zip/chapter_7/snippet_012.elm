100 |> applyTax 0.075
The pipeline feeds the value on the left into the last parameter of the function on the right. This style is common and makes code easy to read.
