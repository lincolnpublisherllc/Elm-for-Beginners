if String.trim value == "" then
