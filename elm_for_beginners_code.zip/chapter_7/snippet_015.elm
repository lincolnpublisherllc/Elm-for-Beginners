|> String.trim
|> String.toLower
|> capFirst
capFirst : String -> String
