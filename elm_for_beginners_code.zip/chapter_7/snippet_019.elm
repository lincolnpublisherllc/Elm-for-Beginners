capFirst (String.toLower (String.trim raw))
