if String.contains "@" value then
