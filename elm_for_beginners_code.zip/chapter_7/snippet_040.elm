type alias Signup =
{ name : String
