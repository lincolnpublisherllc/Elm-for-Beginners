type alias Score =
{ student : String
