1) Forgetting a parameterIf your type says Int -> Int but you wrote n + 1 without a parameter, the compiler will tell you. Add the parameter name on the left of the =.
