Use this for small, focused matches. For more complex shapes, prefer a case inside the function so you can handle more branches.
