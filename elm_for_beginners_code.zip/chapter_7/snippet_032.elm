type alias Point =
{ x : Float, y : Float }
