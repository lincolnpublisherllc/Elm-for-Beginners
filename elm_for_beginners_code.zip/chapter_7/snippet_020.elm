Elm does not have traditional for or while loops. You use recursion or list helpers like List.map, List.filter, and List.foldl. Recursion means a function calls itself with a smaller piece of the problem until it reaches a base case.
The shape of a recursive function
count : List a -> Int
