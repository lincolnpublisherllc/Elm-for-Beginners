mean : List Float -> Maybe Float
Return Nothing for an empty list. Otherwise return the average. Use List.sum and List.length with safe handling.
