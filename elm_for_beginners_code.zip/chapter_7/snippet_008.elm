type alias Totals =
{ subtotal : Float, tax : Float, total : Float }
