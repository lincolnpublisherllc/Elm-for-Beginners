Functions are curried in Elm. A “multi-parameter” function is really a chain of single parameter functions. That allows partial application.
add : Int -> Int -> Int
