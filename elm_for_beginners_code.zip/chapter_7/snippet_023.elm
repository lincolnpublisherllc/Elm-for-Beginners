Base case handles the empty list.
Recursive case handles one element and recurses on the tail.
