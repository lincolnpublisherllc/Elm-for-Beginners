Create a small module Grades.elm that turns raw scores into a final report.
