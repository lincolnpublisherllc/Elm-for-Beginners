The type annotation reads from left to right. Int -> Int means “take an Int and return an Int.”
