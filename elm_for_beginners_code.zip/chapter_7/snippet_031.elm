String.fromFloat (toFloat cents / 100)
