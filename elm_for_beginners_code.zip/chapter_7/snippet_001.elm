With and without type annotations
