case String.uncons s of
Just ( first, rest ) ->
String.fromChar (Char.toUpper first) ++ rest
